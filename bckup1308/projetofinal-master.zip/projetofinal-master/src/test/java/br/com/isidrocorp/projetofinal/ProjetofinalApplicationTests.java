package br.com.isidrocorp.projetofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetofinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
